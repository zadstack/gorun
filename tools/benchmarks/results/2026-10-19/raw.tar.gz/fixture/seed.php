<?php
foreach (json_decode(file_get_contents('/fixture/posts.json'),true) as $p) wp_insert_post(['post_type'=>'post','post_status'=>'publish','post_title'=>$p['title'],'post_name'=>$p['slug'],'post_content'=>$p['body']]);
$dir=WP_CONTENT_DIR.'/themes/benchmark'; wp_mkdir_p($dir);
file_put_contents($dir.'/style.css',"/*\nTheme Name: Benchmark\n*/");
file_put_contents($dir.'/index.php','<?php while(have_posts()):the_post(); ?><!doctype html><html lang="en"><head><title><?php echo esc_html(get_the_title()); ?></title></head><body><article><h1><?php echo esc_html(get_the_title()); ?></h1><?php echo get_the_content(); ?></article></body></html><?php endwhile; ?>');
switch_theme('benchmark');
